
# WiFi Guard Android - สแกนจริงได้

## ทำไม Android สแกนจริงได้ แต่ Web ทำไม่ได้?
- Web Browser: ถูก sandbox ห้ามอ่าน /proc/net/arp และห้ามส่ง raw ICMP
- Android App: มี permission ACCESS_WIFI_STATE + INTERNET + LOCATION สามารถอ่าน ARP table และ ping ได้

## ฟีเจอร์ที่ทำงานจริงบน Android
✅ ดึง subnet ปัจจุบันจาก WifiManager
✅ ping sweep 1-254 เพื่อเติม ARP
✅ อ่าน /proc/net/arp จริง
✅ แยก vendor จาก OUI
✅ ตรวจ hostname ด้วย reverse DNS
✅ แจ้งเตือนอุปกรณ์ใหม่ + บันทึก trusted
✅ ไม่ต้องมี Agent แยก

## วิธี Build APK
1. เปิด Android Studio -> Open โฟลเดอร์นี้
2. Sync Gradle
3. เสียบมือถือ Android ที่ต่อ Wi-Fi เดียวกัน เปิด USB Debugging
4. Run -> จะติดตั้งแอป WiFi Guard
5. Build > Build Bundle(s) / APK(s) > Build APK(s) จะได้ app-debug.apk

## Permission ที่ต้องอนุญาต
- Location (จำเป็นสำหรับ Android 10+ เพื่ออ่าน SSID และ BSSID)
- เมื่อเปิดแอปครั้งแรกให้กด Allow Location

## ข้อจำกัด Android 10+
- MAC ของเครื่องตัวเองจะถูก randomize แต่ MAC ของเครื่องอื่นใน ARP ยังอ่านได้
- บางเครื่องไม่ตอบ ping ต้องใช้หลายวิธีร่วมกัน

## ทางเลือก: Capacitor Wrapper
ถ้าอยากใช้ Web UI เดิม แต่ให้สแกนจริง:
npx cap add android
แล้วเขียน Plugin Native ชื่อ WifiScanner ที่เรียก NetworkScanner.kt เดิม แล้วส่งผลกลับไป WebView ผ่าน JS Bridge
