
# วิธีได้ไฟล์ APK ใน 3 นาที (ไม่ต้องลง Android Studio ก็ได้)

## วิธีที่ 1: ง่ายที่สุด - ใช้ GitHub Actions (แนะนำ)
1. สร้าง Repo ใหม่บน GitHub แล้วอัปโหลดโฟลเดอร์นี้ทั้งหมด
2. ไปที่ Tab Actions -> จะเห็น workflow "Build APK" รันอัตโนมัติ
3. รอ 2-3 นาที -> เข้าไปดาวน์โหลดไฟล์ WiFi-Guard-APK.zip จะได้ app-debug.apk
4. ส่งไฟล์ apk เข้ามือถือแล้วติดตั้งได้เลย

## วิธีที่ 2: ใช้ Android Studio (ได้ APK ทันที)
1. เปิด Android Studio -> Open -> เลือกโฟลเดอร์นี้
2. เสียบมือถือ เปิด USB Debugging
3. กด Run -> แอปจะติดตั้งลงมือถือ
4. Build APK: Menu Build > Build APK(s) -> จะได้ไฟล์ใน app/build/outputs/apk/debug/

## วิธีที่ 3: ใช้ Appetize / Capacitor Live
npx cap add android
npx cap sync
npx cap open android -> Run

## ติดตั้ง APK บนมือถือ
- ต้องเปิด "อนุญาตติดตั้งจากแหล่งที่ไม่รู้จัก" (Install unknown apps)
- มือถือต้องต่อ Wi-Fi เดียวกับที่ต้องการสแกน
- เปิดแอปครั้งแรก -> อนุญาต Location -> กด Scan Network

APK ที่ได้เป็น Debug APK ติดตั้งได้เลย ไม่ต้อง sign สำหรับใช้งานเอง
ถ้าจะขึ้น Play Store ต้องทำ Signing เพิ่ม (ผมใส่ config ไว้ให้แล้ว)
