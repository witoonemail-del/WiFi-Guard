
package com.wifiguard.app

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {

    private val requestPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { perms ->
        if (perms.values.all { it }) {
            // granted
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // ขอ permission ที่จำเป็นสำหรับสแกน Wi-Fi จริง
        val needed = arrayOf(
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.ACCESS_COARSE_LOCATION,
            Manifest.permission.ACCESS_WIFI_STATE
        ).filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (needed.isNotEmpty()) {
            requestPermissionLauncher.launch(needed.toTypedArray())
        }

        setContent {
            WiFiGuardApp()
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun WiFiGuardApp() {
    val context = LocalContext.current
    val scanner = remember { NetworkScanner(context) }
    var devices by remember { mutableStateOf(listOf<Device>()) }
    var isScanning by remember { mutableStateOf(false) }
    var progress by remember { mutableStateOf(0) }
    var lastScan by remember { mutableStateOf<String?>(null) }
    var newAlerts by remember { mutableStateOf(listOf<Device>()) }
    var trustedMacs by remember { mutableStateOf(setOf<String>()) }
    val scope = rememberCoroutineScope()

    // โหลด trusted จาก prefs (ย่อ)
    val knownMacs = remember { mutableStateOf(setOf<String>()) }

    fun doScan() {
        scope.launch {
            isScanning = true
            progress = 0
            try {
                val result = scanner.scan { p -> progress = p }
                // ตรวจจับอุปกรณ์ใหม่
                val newOnes = result.filter { it.mac !in knownMacs.value }
                if (knownMacs.value.isNotEmpty() && newOnes.isNotEmpty()) {
                    newAlerts = newAlerts + newOnes
                    Toast.makeText(context, "พบอุปกรณ์ใหม่ ${newOnes.size} เครื่อง!", Toast.LENGTH_LONG).show()
                }
                knownMacs.value = knownMacs.value + result.map { it.mac }.toSet()
                devices = result.map {
                    it.copy(trustStatus = if (it.mac in trustedMacs) "Trusted" else if (it.mac in knownMacs.value) "Unknown" else "Needs Review")
                }
                lastScan = java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.getDefault()).format(java.util.Date())
            } catch (e: Exception) {
                Toast.makeText(context, "สแกนล้มเหลว: ${e.message}", Toast.LENGTH_SHORT).show()
            } finally {
                isScanning = false
            }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("WiFi Guard", fontWeight = FontWeight.Bold, fontSize = 20.sp)
                        Text(
                            if (lastScan != null) "สแกนล่าสุด: $lastScan" else "พร้อมสแกนเครือข่ายจริง",
                            fontSize = 12.sp, color = Color.Gray
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.White)
            )
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = { doScan() },
                containerColor = Color(0xFF2563EB),
                contentColor = Color.White
            ) {
                Text(if (isScanning) "กำลังสแกน..." else "Scan Network")
            }
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .padding(padding)
                .fillMaxSize()
                .background(Color(0xFFF8FAFC))
                .padding(16.dp)
        ) {
            // Stats
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                StatCard("ทั้งหมด", "${devices.size}", Modifier.weight(1f), Color(0xFF2563EB))
                StatCard("ออนไลน์", "${devices.count { it.isOnline }}", Modifier.weight(1f), Color(0xFF10B981))
                StatCard("ใหม่", "${newAlerts.size}", Modifier.weight(1f), Color(0xFFF59E0B))
            }

            Spacer(Modifier.height(16.dp))

            if (isScanning) {
                LinearProgressIndicator(
                    progress = { progress / 100f },
                    modifier = Modifier.fillMaxWidth().height(6.dp),
                    color = Color(0xFF2563EB)
                )
                Text("กำลังสแกน $progress% - ${scanner.getLocalSubnet()}.0/24", fontSize = 12.sp, color = Color.Gray, modifier = Modifier.padding(top=4.dp))
                Spacer(Modifier.height(12.dp))
            }

            // Alerts
            if (newAlerts.isNotEmpty()) {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFFFF7ED)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(Modifier.padding(12.dp)) {
                        Text("⚠️ ตรวจพบอุปกรณ์ใหม่!", fontWeight = FontWeight.Bold, color = Color(0xFFEA580C))
                        newAlerts.take(3).forEach { d ->
                            Text("${d.hostname} • ${d.ip} • ${d.mac}", fontSize = 12.sp)
                        }
                    }
                }
                Spacer(Modifier.height(12.dp))
            }

            // Device List
            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(devices) { device ->
                    DeviceCard(
                        device = device,
                        onTrust = {
                            trustedMacs = trustedMacs + device.mac
                            devices = devices.map { if (it.mac == device.mac) it.copy(trustStatus = "Trusted") else it }
                            newAlerts = newAlerts.filter { it.mac != device.mac }
                        }
                    )
                }
            }
        }
    }
}

@Composable
fun StatCard(title: String, value: String, modifier: Modifier, color: Color) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White)
    ) {
        Column(Modifier.padding(16.dp)) {
            Text(title, fontSize = 12.sp, color = Color.Gray)
            Text(value, fontSize = 24.sp, fontWeight = FontWeight.Bold, color = color)
        }
    }
}

@Composable
fun DeviceCard(device: Device, onTrust: ()->Unit) {
    val statusColor = if (device.isOnline) Color(0xFF10B981) else Color(0xFF94A3B8)
    val trustColor = when(device.trustStatus) {
        "Trusted" -> Color(0xFF10B981)
        "Needs Review" -> Color(0xFFF59E0B)
        else -> Color.Gray
    }

    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(Modifier.padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(40.dp).background(Color(0xFFEFF6FF), RoundedCornerShape(12.dp)), contentAlignment = Alignment.Center) {
                        Text(
                            when {
                                device.vendor.contains("Apple") -> "📱"
                                device.ip.endsWith(".1") -> "📡"
                                device.vendor.contains("Espressif") -> "💡"
                                else -> "💻"
                            },
                            fontSize = 18.sp
                        )
                    }
                    Spacer(Modifier.width(10.dp))
                    Column {
                        Text(device.customName ?: device.hostname, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                        Text("${device.ip} • ${device.mac}", fontSize = 11.sp, color = Color.Gray)
                    }
                }
                Box(Modifier.background(statusColor.copy(alpha=0.15f), RoundedCornerShape(20.dp)).padding(horizontal = 8.dp, vertical = 4.dp)) {
                    Text(if (device.isOnline) "Online" else "Offline", fontSize = 11.sp, color = statusColor)
                }
            }
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                Text(device.vendor, fontSize = 11.sp, color = Color.Gray)
                Text(device.trustStatus, fontSize = 11.sp, color = trustColor, fontWeight = FontWeight.Bold)
            }
            if (device.trustStatus == "Needs Review") {
                Spacer(Modifier.height(8.dp))
                Button(onClick = onTrust, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2563EB))) {
                    Text("อุปกรณ์ของฉัน (เชื่อถือได้)", fontSize = 12.sp)
                }
            }
        }
    }
}
