
package com.wifiguard.app

import android.content.Context
import android.net.wifi.WifiManager
import android.util.Log
import kotlinx.coroutines.*
import java.io.BufferedReader
import java.io.FileReader
import java.net.InetAddress

data class Device(
    val ip: String,
    val mac: String,
    val vendor: String,
    val hostname: String,
    val isOnline: Boolean,
    val firstSeen: Long = System.currentTimeMillis(),
    var lastSeen: Long = System.currentTimeMillis(),
    var customName: String? = null,
    var trustStatus: String = "Unknown" // Trusted, Unknown, Needs Review
)

object OuiDatabase {
    private val map = mapOf(
        "A4:CF:12" to "Apple, Inc.",
        "3C:22:FB" to "Apple, Inc.",
        "FC:A6:21" to "Samsung Electronics",
        "D8:47:32" to "Xiaomi",
        "B8:27:EB" to "Raspberry Pi",
        "DC:A6:32" to "Raspberry Pi",
        "50:C7:BF" to "TP-Link",
        "EC:08:6B" to "TP-Link",
        "10:BE:F5" to "Espressif (IoT)"
    )
    fun lookup(mac: String): String {
        if (mac.length < 8) return "Unknown"
        val prefix = mac.uppercase().take(8)
        return map[prefix] ?: "Unknown"
    }
}

class NetworkScanner(private val context: Context) {

    fun getLocalSubnet(): String {
        val wm = context.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
        val ipInt = wm.connectionInfo.ipAddress
        val ip = String.format(
            "%d.%d.%d.%d",
            ipInt and 0xff,
            ipInt shr 8 and 0xff,
            ipInt shr 16 and 0xff,
            ipInt shr 24 and 0xff
        )
        // เอา 3 octet แรก เช่น 192.168.1
        return ip.substringBeforeLast(".")
    }

    // อ่าน ARP table จริงจาก /proc/net/arp - ทำได้บน Android
    fun readArpTable(): List<Pair<String,String>> {
        val result = mutableListOf<Pair<String,String>>()
        try {
            BufferedReader(FileReader("/proc/net/arp")).use { reader ->
                reader.readLine() // skip header
                var line: String?
                while (reader.readLine().also { line = it } != null) {
                    val parts = line!!.trim().split("\s+".toRegex())
                    if (parts.size >= 4) {
                        val ip = parts[0]
                        val mac = parts[3].uppercase()
                        if (mac.matches(Regex("..:..:..:..:..:..")) && mac != "00:00:00:00:00:00") {
                            result.add(ip to mac)
                        }
                    }
                }
            }
        } catch (e: Exception) {
            Log.e("WiFiGuard", "ARP read error", e)
        }
        return result
    }

    // ping sweep เพื่อเติม ARP table
    suspend fun pingSweep(subnet: String) = withContext(Dispatchers.IO) {
        val jobs = (1..254).map { i ->
            async {
                try {
                    val ip = "$subnet.$i"
                    val addr = InetAddress.getByName(ip)
                    addr.isReachable(300) // ICMP / TCP fallback
                } catch (_: Exception) { }
            }
        }
        jobs.awaitAll()
    }

    suspend fun scan(onProgress: (Int)->Unit): List<Device> = withContext(Dispatchers.IO) {
        val subnet = getLocalSubnet()
        onProgress(10)
        pingSweep(subnet)
        onProgress(60)
        val arpEntries = readArpTable()
        onProgress(80)

        val devices = arpEntries.map { (ip, mac) ->
            var hostname = "Unknown Device"
            try {
                hostname = InetAddress.getByName(ip).canonicalHostName ?: ip
                if (hostname == ip) {
                    // reverse lookup fail
                    hostname = "Unknown Device"
                }
            } catch (_: Exception) {}
            Device(
                ip = ip,
                mac = mac,
                vendor = OuiDatabase.lookup(mac),
                hostname = hostname,
                isOnline = true
            )
        }.distinctBy { it.mac }

        onProgress(100)
        return@withContext devices
    }
}
